<?php
$host = 'localhost';
$user = 'root';
$pass = 'admin';
$db = 'chatdb';
$title = 'Chat với người lạ';
?>
