function ChatController($scope, $http, $timeout, $log){

	(function init(){
		var userId, strangerId;
		$scope.chats= [];

		startChat();
		getNumberOfOnlineUsers();
	})();

	function startChat(){
		$http.get('getUserId.php').success(function(uid){
			userId= uid;
			checkFirstVisit();
			$scope.loading= true;
			randomChat();
		});
	}

	function getNumberOfOnlineUsers(){
		$http.get('getNumberOfOnlineUsers.php').success(function(data){
			$scope.useronline= data;
		});
		$timeout(getNumberOfOnlineUsers, 1000);
	}

	function leaveChat(){
		checkFirstVisit();
		return;
	};
	window.onbeforeunload= leaveChat;

	function checkFirstVisit() {
		var c= document.cookie,
			name= 'useronline=';

		if(c.indexOf(name)==-1) {
    		document.cookie = name+ userId;
		}else {
    		// not first visit
    		var olduseronline= c.substring(name.length,c.length);
    		$http.get('leaveChat.php?userId='+ olduseronline).success(function(){
    			document.cookie = name+ userId;
    		});
		}
	}

	function randomChat(){
		$http.get('getStrangerId.php?userId='+ userId).success(function(sid){
			strangerId= sid;
			if(strangerId== "0"){
				$timeout(randomChat, 1000);
			}else{
				$scope.loading= false;
				$scope.chats.push({
				'info':'Người lạ vừa vào phòng. Chào hỏi nhau đê!'
			});
				listenToRecieve();
			}
		});
	};

	function listenToRecieve(){
		$http.get('listenToRecieve.php?userId='+ userId).success(function(data){
			if(data=='||--noResult--||'){
				$scope.loading= true;
				$scope.chats.push({
					'info':'Người lạ đã rời phòng. Đang chờ người khác...'
				});
				leaveChat();
				startChat();
				return;
			}else if(data != ''){
				var chat= {
					'type':'stranger',
					'name':'người lạ',
					'message': data
				};
				$scope.chats.push(chat);
			};
			$timeout(listenToRecieve, 1000);
		});
	};

	$scope.sendMessage = function(message){
		$http.get('sendMessage.php?userId='+ userId+
			'&strangerId='+ strangerId+
			'&message='+ message
		).success(function(data){
			$scope.chats.push({
				'type':'you',
				'name':'bạn',
				'message': message
			});
			$scope.message= '';
		});
	};
}